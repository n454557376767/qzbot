token = None
def set_token(new_token:str):
    global token
    token = new_token
